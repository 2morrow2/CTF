import hashlib

for i in range(65, 123):
	for j in range(65, 123):
		for k in range(65, 123):
			#print(chr(i)+chr(j))
			a = chr(i) + chr(j) + chr(k)
			b = hashlib.sha256(a.encode()).hexdigest()
			if b[0:3]=='100' or b[0:4]=='0100' or b[0:5]=='00100' or b[0:6]=='000100' or b[0:7]=='0000100' or b[0:3]=='1e2' or b[0:4]=='01e2' or b[0:5]=='001e2' or b[0:6]=='0001e2' or b[0:7]=='00001e2':
				print(a)
				print(b)